# Verification record

6 September 2026. These checks were run by the coding assistant, not a claim
that Shiva completed the practice exercises. No independent reviewer scores
or public model benchmarks are claimed.

## Executed

- CSV authored and inspected with the spreadsheet tooling: 24 data rows and
  five columns. All rows parsed back through Python's CSV reader.
- Notebook format validated before and after execution.
- All 13 code cells executed sequentially in a fresh Jupyter kernel with
  `RUN_LLM = False`; zero notebook error outputs.
- 24 unit/contract tests passed with Python 3.12 and OpenAI SDK 2.54.0.
- The SDK integration test uses an HTTP mock transport, not a live endpoint.
- Rules baseline: 17 true-positive occurrences, 1 false positive, 8 false
  negatives; 16 of 24 rows match the authored answer set exactly.
- All five authored candidate replacements checked against an explicit
  expected masked string. Original row and metadata preserved.
- Repeated values, Unicode, multiline input, conflicting overlaps, invented
  candidates, malformed structures, refusal/incomplete-response handling,
  provider-error redaction and disabled-network behavior covered.
- Public-file pattern scan found no real API-key pattern, private-key block
  or machine-specific home path in the shareable files. This is a limited
  scan, not a confidentiality certification.

## Not executed or established

- No paid or live LLM request.
- No actual model precision/recall or live hybrid result.
- No production deployment, independent privacy audit or real-data test.
- No public GitHub upload, LinkedIn publication or resume/website change.
- No confirmation yet of Shiva's practical mastery.

## Reproduce

```bash
python3 run_demo.py
python3 -m unittest discover -s tests -v
# With notebook dependencies installed; local loopback access is required:
python3 execute_notebook.py
```

The notebook executor needs a local kernel connection. During assistant QA,
the restricted environment initially blocked the loopback port; the notebook
was then successfully executed with that local permission. The API section
remained disabled. Temporary kernel files were cleaned up.
