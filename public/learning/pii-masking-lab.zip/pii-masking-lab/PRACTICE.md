# Practice and explain before posting

Completion is not checked off by code generation. Record your own run below.

## First session: this notebook

- [ ] Run all default cells with `RUN_LLM = False`.
- [ ] Explain a CSV row, a Python dictionary, the entities list and one JSON item.
- [ ] Predict the five masks before running the first example.
- [ ] Explain why replacements run from right to left.
- [ ] Explain why repeat@example.com produces two scored occurrences.
- [ ] Find the 8 missed occurrences and the 1 unnecessary mask in the report.
- [ ] Explain why zero re-scan matches is not privacy clearance.
- [ ] Break a candidate deliberately and observe the row being held.
- [ ] Run the optional three-row LLM experiment only if you choose to spend and
      have an available model. Record model ID/date and actual outputs.
- [ ] Compare rules-only, LLM-only and union-hybrid behavior on the order reference.
- [ ] Add three NEW fictional challenge rows without looking at their results,
      then label, test and explain one justified improvement and its tradeoff.

Finish line: explain the workflow without reading the README, reproduce the
results, and explain one false negative and one false positive honestly.

My run date:
My model, if any:
What I changed:
Before/after results on unchanged cases:
New challenge cases:
What I still cannot explain:

## Separate next session: Constraint-Aware Coding Agent Evaluation Lab

Keep that existing project separate. Its current canonical location is:
https://github.com/omni-shiva/shiva-applied-agentic/tree/main/projects/constraint-aware-coding-agent-evals

- Run its documented offline `validate`, `check-probes` and `evaluate` commands.
- Explain why both candidates can pass functional tests but differ on contracts.
- Trace one of its six runtime probes.
- Predict what happens if a candidate mutates inputs or reads the clock twice.
- Make a small local practice change, then explain the before/after evidence.

This file does not claim these exercises have been completed and does not
change or republish that repository.
