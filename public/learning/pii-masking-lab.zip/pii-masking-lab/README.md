# PII masking practice lab

A small, runnable notebook for understanding how sensitive-data detection,
validation and code-based masking fit together. Independently authored with
AI assistance for learning. No employer/client data, no training or deployment
claim, and no claim that the learner has mastered it yet.

**Start with [the notebook](pii_masking_walkthrough.ipynb).** It uses
[24 fictional support tickets in a CSV](data/synthetic_support_tickets.csv).
You do not need to find or download real customer data.

## What you can run

1. A standard-library regex baseline: runs offline, no key, no model.
2. Exact candidate validation and deterministic masking: all five types.
3. Evaluation against separately stored authored answers: count misses and
   unnecessary masking, including repeated occurrences.
4. An optional OpenAI structured-output experiment: disabled by default,
   requires your model choice and API key, can incur charges.
5. A deliberately simple hybrid union to show why adding two detectors can
   improve recall but also preserve or introduce false positives.

This is a teaching lab, **not a production-ready privacy filter**. The five
types are ADDRESS, EMAIL, PHONE, BANK_ACCOUNT and PAYMENT_CARD. Only the
`issue_summary` field is in scope. See [the dataset card](DATASET_CARD.md).

## Run immediately, no installation

From this repository folder, using Python 3.10 or newer:

```bash
python3 run_demo.py
python3 -m unittest discover -s tests -v
```

The demo writes `reports/baseline_metrics.json` and
`reports/baseline_masked.csv`. Those outputs are labeled as a baseline, not
data cleared for release. No network request is made.

Verified locally on 6 September 2026: all 13 default notebook code cells
executed in a fresh kernel; 24 tests passed with the optional SDK installed.
Without the SDK, its one HTTP-contract test is skipped and the other 23
tests run with the standard library. See [verification notes](VERIFICATION.md).

## Open the notebook

Use your existing Jupyter environment, or create a separate environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m jupyter lab pii_masking_walkthrough.ipynb
```

On Windows, activate with `.venv\Scripts\activate` instead. Select this
environment's Python kernel. The notebook displays the actual implementation
functions and explains them, then runs the examples. Keep `RUN_LLM = False`
for your first pass. In Colab, upload/clone the whole project so the CSV and
Python files remain alongside the notebook, not just the notebook alone.

## What was actually measured

The supplied offline baseline finds 17 of 25 labeled entity occurrences,
misses 8, and masks one non-card order reference unnecessarily. It matches
the expected detections on 16 of 24 rows. Precision is 17/18 and recall is
17/25 **on these authored teaching fixtures only**.

The baseline intentionally does not detect addresses or written-out email
addresses. A valid Luhn checksum cannot determine the meaning of a number.
These are useful failures to study, not evidence that LLMs will fix them.

**Live LLM and hybrid model results: NOT RUN.** Fake-client tests check request
shape and failure handling, not model accuracy. The notebook lets you measure
those modes yourself on three selected fixtures before expanding the run.

## How the code fits together

```text
CSV text -> candidate detector -> validate exact occurrences -> mask right to left
                  |                                              |
             rules or LLM                                  pattern-only re-scan
                  |                                              |
        compare with separate labels                 review, not privacy clearance
```

- [masking.py](masking.py): definitions, regex baseline, validation, masks,
  simple hybrid merge and occurrence-level evaluation.
- [llm_detector.py](llm_detector.py): optional provider call, JSON schema,
  explicit network opt-in, no raw-text fallback on errors.
- [tests](tests/test_masking.py): example correctness plus behavioral contracts.
- [practice checklist](PRACTICE.md): exercises and finish line.

## Important limits

- This dataset is authored and small, not a representative benchmark or
  training set. Do not report its scores as production accuracy.
- Shape validation cannot prove that a candidate's type is correct, or that
  every entity was found. An empty result is not privacy clearance.
- The re-scan reuses narrow regex rules. It is not an independent detector
  and can miss the same information as the first pass.
- The illustrative hybrid merges candidates by union. If the regex mistakes
  an order reference for a card, an empty LLM result does not remove that false
  positive. Learn this tradeoff before adding reconciliation logic.
- Only fictional/approved data belongs in the optional API call. `store=False`
  does not establish zero retention or permission to send sensitive data.
- Keep keys out of files, notebook outputs, logs and Git. Do not replace the
  sample CSV with employer/customer data. Masking is not encryption and does
  not guarantee anonymization.
- There are no hidden live calls: the default demo and tests stay offline.

## References

- [Ed Donner, Week 1 Day 5](https://github.com/ed-donner/llm_engineering/blob/main/week1/day5.ipynb):
  system/user messages and a typed JSON classification example. The PII scenario
  here is an application of those concepts, not the course's exact project.
- [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs):
  schema-constrained responses. This lab still checks exact source text and
  handles refusal, incomplete output and invalid candidates.
- [Presidio](https://github.com/data-privacy-stack/presidio): hybrid recognition
  concepts and automated-detection limitations. Presidio is a reference, not
  an installed component in this small lab.
- [Stripe test cards](https://docs.stripe.com/testing): the public `4242` test
  card value. It is used only as fictional text here.

## Sharing and mastery

This local project has no verified public URL yet. Once published, link the
repository README and the notebook from the post. Do not invent a GitHub link.
Before using first-person implementation claims, run the notebook, explain
its failures, make one justified change and compare the results. Keep an
honest note of what you personally ran and what remains untested.
