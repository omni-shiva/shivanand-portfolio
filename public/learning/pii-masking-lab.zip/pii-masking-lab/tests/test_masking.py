import copy
import json
import unittest
from types import SimpleNamespace

from masking import (CandidateError, MASKS, detect_with_rules, evaluate,
                     luhn_valid, mask_record, mask_text, merge_candidates,
                     rescan, validate_candidates)
from llm_detector import detect_with_llm
from run_demo import load_data


def candidate(kind, text):
    return {"entities": [{"type": kind, "text": text}]}


class MaskingTests(unittest.TestCase):
    def test_all_five_against_explicit_expected_text(self):
        rows, gold = load_data()
        expected = ("Device restarts during setup. Deliver to [ADDRESS]. Email [EMAIL] "
                    "or call [PHONE]. Refund details: bank account [BANK_ACCOUNT]; card [PAYMENT_CARD].")
        self.assertEqual(mask_text(rows[0]["issue_summary"], gold["DEMO-001"]), expected)

    def test_repeated_values_and_duplicate_candidates(self):
        text = "a@example.com then a@example.com"
        payload = {"entities": [{"type": "EMAIL", "text": "a@example.com"}] * 2}
        self.assertEqual(len(validate_candidates(text, payload)), 2)
        self.assertEqual(mask_text(text, payload), "[EMAIL] then [EMAIL]")

    def test_right_to_left_replacement(self):
        text = "a@example.com or longer.email@example.org"
        payload = {"entities": [{"type": "EMAIL", "text": value} for value in
                                ["a@example.com", "longer.email@example.org"]]}
        self.assertEqual(mask_text(text, payload), "[EMAIL] or [EMAIL]")

    def test_unicode_and_multiline(self):
        self.assertEqual(mask_text("📦\n7 Éxample Road\nLate.", candidate("ADDRESS", "7 Éxample Road")),
                         "📦\n[ADDRESS]\nLate.")

    def test_literal_matching_not_regex_execution(self):
        self.assertEqual(mask_text("a+b@example.com", candidate("EMAIL", "a+b@example.com")), "[EMAIL]")

    def test_empty_and_already_masked(self):
        for text in ["", "[EMAIL] and [ADDRESS]"]:
            self.assertEqual(mask_text(text, detect_with_rules(text)), text)

    def test_rejects_invalid_candidates(self):
        bad = [None, [], {}, {"entities": None}, {"entities": [], "extra": True},
               {"entities": [None]}, candidate("OTHER", "value"), candidate([], "value"),
               candidate("EMAIL", ""), candidate("EMAIL", " "), candidate("EMAIL", "invented"),
               {"entities": [{"type": "EMAIL", "text": "value", "confidence": 1}]}]
        for payload in bad:
            with self.subTest(payload=payload), self.assertRaises(CandidateError):
                mask_text("value", payload)

    def test_overlapping_types_require_review(self):
        payload = {"entities": [{"type": "ADDRESS", "text": "abc"}, {"type": "EMAIL", "text": "bc"}]}
        with self.assertRaises(CandidateError):
            mask_text("abc", payload)

    def test_same_span_conflicting_types_require_review(self):
        with self.assertRaises(CandidateError):
            merge_candidates("abc", candidate("ADDRESS", "abc"), candidate("EMAIL", "abc"))

    def test_original_row_and_metadata_unchanged(self):
        rows, gold = load_data()
        before = copy.deepcopy(rows[0])
        result = mask_record(rows[0], gold["DEMO-001"])
        self.assertIsNot(result, rows[0])
        self.assertEqual(rows[0], before)
        for key in ["ticket_id", "category", "created_at", "status"]:
            self.assertEqual(result[key], before[key])

    def test_hybrid_union_deduplicates_but_does_not_fix_false_positive(self):
        email = candidate("EMAIL", "a@example.com")
        self.assertEqual(len(validate_candidates("a@example.com", merge_candidates("a@example.com", email, email))), 1)
        text = "Order reference 4242424242424242 is not a payment card."
        merged = merge_candidates(text, detect_with_rules(text), {"entities": []})
        self.assertIn("[PAYMENT_CARD]", mask_text(text, merged))


class EvaluationTests(unittest.TestCase):
    def test_dataset_shape_and_label_alignment(self):
        rows, gold = load_data()
        self.assertEqual(len(rows), 24)
        self.assertEqual(set(rows[0]), {"ticket_id", "category", "created_at", "status", "issue_summary"})
        seen = set()
        for row in rows:
            spans = validate_candidates(row["issue_summary"], gold[row["ticket_id"]])
            seen.update(span.type for span in spans)
        self.assertEqual(seen, set(MASKS))

    def test_measured_baseline_has_known_failures(self):
        rows, gold = load_data()
        result = evaluate(rows, gold, detect_with_rules)
        self.assertEqual((result["tp"], result["fp"], result["fn"], result["exact_rows"]), (17, 1, 8, 16))
        self.assertEqual(result["recall"], 17 / 25)
        self.assertAlmostEqual(result["precision"], 17 / 18)

    def test_detector_receives_only_text_once_per_row(self):
        rows, gold = load_data()
        observed = []
        def recording_detector(text):
            observed.append(text)
            return {"entities": []}
        evaluate(rows, gold, recording_detector)
        self.assertEqual(observed, [row["issue_summary"] for row in rows])

    def test_invalid_result_is_held_and_misses_are_counted(self):
        rows = [{"ticket_id": "x", "issue_summary": "a@example.com"}]
        result = evaluate(rows, {"x": candidate("EMAIL", "a@example.com")}, lambda text: {})
        self.assertEqual((result["held"], result["fn"]), (1, 1))
        self.assertIsNone(result["details"][0]["masked_summary"])

    def test_missing_labels_and_duplicate_ids_rejected(self):
        rows, gold = load_data()
        with self.assertRaises(ValueError):
            evaluate(rows, {}, detect_with_rules)
        with self.assertRaises(ValueError):
            evaluate(rows + [rows[0]], gold, detect_with_rules)

    def test_no_sensitive_labels_or_predictions(self):
        result = evaluate([{"ticket_id": "x", "issue_summary": ""}], {"x": {"entities": []}}, detect_with_rules)
        self.assertIsNone(result["precision"])
        self.assertIsNone(result["recall"])
        self.assertEqual(result["exact_rows"], 1)

    def test_pattern_rescan_can_miss_an_address(self):
        scan = rescan("Deliver to 42 Example Lane, Sample City.")
        self.assertEqual(scan["remaining_pattern_candidates"], 0)
        self.assertIn("does not prove privacy", scan["note"])

    def test_checksum_is_not_semantic_evidence(self):
        self.assertTrue(luhn_valid("4242 4242 4242 4242"))
        self.assertFalse(luhn_valid("4242 4242 4242 4243"))
        self.assertEqual(len(detect_with_rules("Order reference 4242424242424242.")["entities"]), 1)


class LLMContractTests(unittest.TestCase):
    """Fake-client contract checks only. No model performance is measured here."""

    def fake(self, output='{"entities":[{"type":"EMAIL","text":"a@example.com"}]}', status="completed"):
        self.calls = []
        def create(**kwargs):
            self.calls.append(kwargs)
            return SimpleNamespace(status=status, output_text=output)
        return SimpleNamespace(responses=SimpleNamespace(create=create))

    def test_network_disabled_by_default(self):
        fake = self.fake()
        with self.assertRaises(CandidateError):
            detect_with_llm("a@example.com", model="test-model", client=fake)
        self.assertEqual(self.calls, [])

    def test_contract_role_separation_and_store_false(self):
        payload = detect_with_llm("a@example.com", model="test-model", allow_network=True, client=self.fake())
        self.assertEqual(payload, candidate("EMAIL", "a@example.com"))
        call = self.calls[0]
        self.assertEqual(len(self.calls), 1)
        self.assertFalse(call["store"])
        self.assertEqual([item["role"] for item in call["input"]], ["system", "user"])
        self.assertTrue(call["text"]["format"]["strict"])

    def test_refusal_truncation_and_invalid_json_fail_closed(self):
        for output, status in [("", "completed"), ("", "incomplete"), ("not JSON", "completed"),
                               ('{"entities":[{"type":"EMAIL","text":"hallucinated"}]}', "completed")]:
            with self.subTest(output=output), self.assertRaises(CandidateError):
                detect_with_llm("a@example.com", model="test-model", allow_network=True, client=self.fake(output, status))

    def test_provider_errors_not_echoed_and_no_raw_fallback(self):
        def create(**kwargs):
            raise RuntimeError("A provider error containing SECRET_RAW_INPUT")
        fake = SimpleNamespace(responses=SimpleNamespace(create=create))
        with self.assertRaises(CandidateError) as caught:
            detect_with_llm("a@example.com", model="test-model", allow_network=True, client=fake)
        self.assertNotIn("SECRET_RAW_INPUT", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
