"""Real SDK, fake HTTP transport. No API requests or model performance tests."""

import importlib.util
import json
import unittest

from llm_detector import detect_with_llm


@unittest.skipUnless(importlib.util.find_spec("openai"), "Optional OpenAI SDK not installed")
class SDKContractTests(unittest.TestCase):
    def test_actual_sdk_request_and_response_shape_without_network(self):
        import httpx
        from openai import OpenAI
        captured = []

        def handler(request):
            captured.append(json.loads(request.content))
            self.assertEqual(request.url.path, "/v1/responses")
            return httpx.Response(200, json={
                "id": "resp_synthetic_contract", "object": "response",
                "created_at": 0, "status": "completed", "model": "contract-test-only",
                "output": [{"id": "msg_synthetic", "type": "message", "role": "assistant",
                            "status": "completed", "content": [{"type": "output_text",
                            "text": '{"entities":[{"type":"EMAIL","text":"a@example.com"}]}',
                            "annotations": []}]}],
            })

        with httpx.Client(transport=httpx.MockTransport(handler)) as http:
            with OpenAI(api_key="fake-key-for-local-contract-test", http_client=http, max_retries=0) as client:
                result = detect_with_llm("a@example.com", model="contract-test-only", allow_network=True, client=client)
        self.assertEqual(len(captured), 1)
        self.assertEqual(result["entities"][0]["text"], "a@example.com")
        self.assertFalse(captured[0]["store"])
        self.assertEqual(captured[0]["text"]["format"]["type"], "json_schema")
        self.assertTrue(captured[0]["text"]["format"]["strict"])


if __name__ == "__main__":
    unittest.main()
