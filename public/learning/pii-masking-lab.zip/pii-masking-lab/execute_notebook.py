"""Validate and execute default notebook cells in a clean Jupyter kernel."""

from pathlib import Path
import os
import sys
from tempfile import TemporaryDirectory
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager


root = Path(__file__).resolve().parent
path = root / "pii_masking_walkthrough.ipynb"
notebook = nbformat.read(path, as_version=4)
nbformat.validate(notebook)
# The default notebook must never silently become a paid-API test.
if not any("RUN_LLM = False" in cell.source for cell in notebook.cells if cell.cell_type == "code"):
    raise RuntimeError("Default offline opt-out is missing.")
with TemporaryDirectory(prefix="pii-notebook-") as runtime:
    os.environ["JUPYTER_RUNTIME_DIR"] = runtime
    os.environ["IPYTHONDIR"] = runtime
    manager = KernelManager(kernel_name="python3")
    # Use this isolated environment, not an arbitrary globally registered kernel.
    manager.kernel_spec.argv = [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"]
    try:
        NotebookClient(notebook, timeout=90, km=manager,
                       resources={"metadata": {"path": str(root)}}).execute()
    finally:
        if manager.has_kernel:
            manager.shutdown_kernel(now=True)
errors = [out for cell in notebook.cells if cell.cell_type == "code"
          for out in cell.get("outputs", []) if out.get("output_type") == "error"]
if errors:
    raise RuntimeError("Notebook has error outputs.")
nbformat.validate(notebook)
nbformat.write(notebook, path)
count = sum(cell.cell_type == "code" for cell in notebook.cells)
print(f"Executed {count} code cells successfully. Default LLM section remained disabled.")
