"""A small teaching lab, not a production privacy filter. No network imports."""

from dataclasses import dataclass
import re


ENTITY_DEFINITIONS = {
    "ADDRESS": "A person's home or delivery location, including street/locality. A general city mention alone is not an address.",
    "EMAIL": "A contact email address, including clearly written-out forms such as name [at] domain [dot] com. Copy the original text exactly.",
    "PHONE": "A phone or mobile contact number, including country code and separators.",
    "BANK_ACCOUNT": "An account identifier in banking or refund context. A bank name or balance alone is not an account identifier.",
    "PAYMENT_CARD": "A full debit or credit card number, with any spaces or hyphens. Do not classify an explicitly identified order reference as a card just because its digits fit.",
}
MASKS = {kind: f"[{kind}]" for kind in ENTITY_DEFINITIONS}


class CandidateError(ValueError):
    """Invalid or conflicting candidates: hold this row, do not release raw text."""


@dataclass(frozen=True, order=True)
class Span:
    start: int
    end: int
    type: str


def validate_candidates(text, payload):
    """Validate shape and exact occurrences. This cannot prove semantic accuracy.

    Return character spans in the ORIGINAL Python string. Repeated exact values
    are expanded to all occurrences. Deduplicate identical candidates; reject
    overlaps rather than guessing which category wins.
    """
    if not isinstance(text, str):
        raise CandidateError("Input must be text.")
    if not isinstance(payload, dict) or set(payload) != {"entities"}:
        raise CandidateError("Expected one entities field.")
    items = payload["entities"]
    if not isinstance(items, list) or len(items) > 100:
        raise CandidateError("Expected at most 100 candidate items.")
    spans = set()
    for item in items:
        if not isinstance(item, dict) or set(item) != {"type", "text"}:
            raise CandidateError("Each item needs exactly type and text.")
        kind, value = item["type"], item["text"]
        if not isinstance(kind, str) or kind not in MASKS:
            raise CandidateError("Unknown entity type.")
        if not isinstance(value, str) or not value.strip():
            raise CandidateError("Candidate text cannot be empty.")
        matches = list(re.finditer(re.escape(value), text))
        if not matches:
            raise CandidateError("Candidate does not occur exactly in the input.")
        for match in matches:
            spans.add(Span(match.start(), match.end(), kind))
    ordered = sorted(spans)
    if any(right.start < left.end for left, right in zip(ordered, ordered[1:])):
        raise CandidateError("Overlapping candidates require review.")
    return ordered


def mask_text(text, payload):
    """Replace right to left so earlier character positions remain valid."""
    spans = validate_candidates(text, payload)
    result = text
    for span in reversed(spans):
        result = result[:span.start] + MASKS[span.type] + result[span.end:]
    return result


def mask_record(row, payload):
    """Change ONLY issue_summary in a new dictionary; preserve the input row."""
    return {**row, "issue_summary": mask_text(row["issue_summary"], payload)}


def luhn_valid(value):
    """A checksum, not proof that a number is a payment card."""
    digits = [int(c) for c in value if c.isascii() and c.isdigit()]
    if len(digits) != 16:
        return False
    total = 0
    for index, digit in enumerate(reversed(digits)):
        if index % 2:
            digit *= 2
            digit = digit - 9 if digit > 9 else digit
        total += digit
    return total % 10 == 0


# Deliberately small, inspectable baseline. NOT comprehensive recognizers.
PATTERNS = {
    "EMAIL": re.compile(r"(?<![\w.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w-])"),
    "PHONE": re.compile(r"(?<!\w)\+1[ -]?\(?\d{3}\)?[ -]\d{3}[ -]\d{4}(?!\d)"),
    "BANK_ACCOUNT": re.compile(r"\bDEMO-ACCT-\d{3}\b"),
    "PAYMENT_CARD": re.compile(r"(?<!\d)(?:\d[ -]?){15}\d(?!\d)"),
}


def detect_with_rules(text):
    """Regex baseline for four patterns. No address detector or language model.

    Its narrow US-style phone/demo-account rules are for these teaching
    fixtures. Evaluate its misses and false positives before changing it.
    """
    items = []
    for kind, pattern in PATTERNS.items():
        for match in pattern.finditer(text):
            value = match.group()
            if kind != "PAYMENT_CARD" or luhn_valid(value):
                items.append({"type": kind, "text": value})
    return {"entities": items}


def merge_candidates(text, *payloads):
    """Simple union. A union may add false positives; it is not always better."""
    items = []
    for payload in payloads:
        validate_candidates(text, payload)
        items.extend(payload["entities"])
    merged = {"entities": items}
    validate_candidates(text, merged)
    return merged


def rescan(masked_text):
    """A pattern-only check, explicitly NOT an independent privacy clearance."""
    remaining = detect_with_rules(masked_text)
    return {
        "remaining_pattern_candidates": len(remaining["entities"]),
        "note": "Pattern-only re-scan. Zero matches does not prove privacy.",
    }


def evaluate(rows, gold, detector):
    """Occurrence-level exact span/type scoring. Labels never enter detector.

    Held/invalid rows count all their expected entities as missed, preventing
    failures from disappearing from the reported recall denominator.
    """
    ids = [row["ticket_id"] for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate ticket IDs would distort the evaluation.")
    if set(ids) != set(gold):
        raise ValueError("Rows and expected-answer IDs must match.")
    details = []
    tp = fp = fn = exact_rows = held = 0
    for row in rows:
        key, text = row["ticket_id"], row["issue_summary"]
        expected = set(validate_candidates(text, gold[key]))
        try:
            payload = detector(text)  # IMPORTANT: only text, never gold labels.
            found = set(validate_candidates(text, payload))
            masked = mask_text(text, payload)
            error = None
        except CandidateError:
            found, masked, error = set(), None, "Candidate validation failed; held for review."
            held += 1
        hits, extra, missed = len(found & expected), len(found - expected), len(expected - found)
        exact = error is None and found == expected
        tp += hits
        fp += extra
        fn += missed
        exact_rows += int(exact)
        details.append({
            "ticket_id": key, "tp": hits, "fp": extra, "fn": missed,
            "exact_match": exact, "held": error is not None,
            "masked_summary": masked,
            "re_scan": rescan(masked) if masked is not None else None,
        })
    return {
        "rows": len(rows), "tp": tp, "fp": fp, "fn": fn, "held": held,
        "precision": tp / (tp + fp) if tp + fp else None,
        "recall": tp / (tp + fn) if tp + fn else None,
        "exact_rows": exact_rows, "details": details,
    }
