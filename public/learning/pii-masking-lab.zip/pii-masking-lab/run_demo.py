"""Run the no-network baseline and write explicitly labeled local reports."""

import csv
import json
from pathlib import Path

from masking import detect_with_rules, evaluate


ROOT = Path(__file__).resolve().parent


def load_data(root=ROOT):
    with (root / "data/synthetic_support_tickets.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    gold = json.loads((root / "data/expected_entities.json").read_text(encoding="utf-8"))
    return rows, gold


def main():
    rows, gold = load_data()
    result = evaluate(rows, gold, detect_with_rules)
    result["mode"] = "rules_only_no_model_called"
    result["dataset"] = "24 authored teaching fixtures, not a representative benchmark"
    result["llm_run"] = "NOT_RUN"
    target = ROOT / "reports"
    target.mkdir(exist_ok=True)
    (target / "baseline_metrics.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with (target / "baseline_masked.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = [*rows[0], "evaluation_status"]
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row, detail in zip(rows, result["details"]):
            writer.writerow({**row, "issue_summary": detail["masked_summary"],
                             "evaluation_status": "HELD" if detail["held"] else "BASELINE_ONLY_NOT_PRIVACY_CLEARED"})
    print(json.dumps({k: v for k, v in result.items() if k != "details"}, indent=2))
    print("Reports are educational outputs, not cleared data for downstream use.")


if __name__ == "__main__":
    main()
