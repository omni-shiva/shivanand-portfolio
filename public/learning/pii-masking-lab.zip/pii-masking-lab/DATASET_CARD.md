# Synthetic support-ticket dataset

## Origin

All 24 records and their expected labels were newly authored for this teaching
lab with AI assistance. No source system was queried, no customer records were
scraped, and no real data was anonymized to create these examples. The records
are not actual LLM-generated support summaries; they simulate such free text.

The CSV has exactly five fields: `ticket_id`, `category`, `created_at`, `status`
and `issue_summary`. All are text. The first four are synthetic metadata and
must remain unchanged. The date is fictional example metadata, not an event
history. Empty and multiline summaries are intentional CSV cases.

## Fictional identifiers

- Email addresses use example.com, example.org or example.net domains.
- Phone fixtures use the fictional 202-555-01xx range.
- Addresses use Example/Fictional/Demo street and city descriptions and are
  not taken from an address database.
- `DEMO-ACCT-001` style values are demo identifiers, not realistic bank-account
  validation examples.
- `4242 4242 4242 4242` is a published Stripe test-card value. The same digits
  deliberately appear once in an order-reference context to test over-masking.

## Label policy

The five types are defined in `masking.ENTITY_DEFINITIONS`. Names, secrets,
medical details, government IDs and other personal data types are outside
this exercise, not safe to publish. This is not a complete privacy policy.

Each label stores a type and exact original text. A repeated exact value is
listed once and expanded to all its non-overlapping occurrences for scoring.
There are 25 labeled entity occurrences in total, not 25 unique values.

Written-out contact email counts as EMAIL. Home/delivery locations count as
ADDRESS. General city mentions, bank names, amounts, error codes and explicit
order references do not count under this teaching policy. Labels are authored
expectations, not annotations produced by a reviewed external dataset.

## Coverage and limitations

The set includes all five types, no-entity rows, repeated and multiple entities,
Unicode, line breaks, an obfuscated email, already-masked text, an empty field,
a prompt-injection sentence and a numeric false-positive trap.

There is no train/test split: this is a transparent teaching fixture set, not
a model-training corpus. If you tune rules/prompts against it, a higher score
only shows a better fit to these cases. Author a separate untouched challenge
set before making broader comparisons. Never pass expected labels into a
detector or label a prerecorded candidate list as a live model response.
